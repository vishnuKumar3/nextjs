

export function Details() {
	const details={
		name:"*****************",
		phone:'83******63',
		mail:"ss@gmail.com"
		}	
  return details

  
}
