import styles from '../styles/Home.module.css'

export default function About() {
  return (
    <div className={styles.container}>
      <p className={styles.shrink}>This is About page</p>
    </div>
  )
}
