import styles from '../styles/Home.module.css'

export default function Career() {
  return (
    <div className={styles.container}>
     <p className={styles.shrink}>This is Career page</p>

       
    </div>
  )
}
