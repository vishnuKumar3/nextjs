import Link from 'next/link'
import Head from 'next/head'
import styles from '../styles/Home.module.css'
import {Details} from './name'



export default function Home({details}) {
  return (
	
	<div className={styles.container1}>
	<Head>
	<link rel="icon" href="image.jpg" href="/solution.svg"/>
	</Head>
	<p className={styles.main2}>S</p>
	<p className={styles.main1}>S</p>
	<p className={styles.desc}>Solution For Every Problem</p>	
	<img src="solution.svg" className={styles.solutionpic}/>
	
	
	
	<img className={styles.pic} src="/problem.jpg" />
	<div className={styles.footer}>
	<p >For any software solutions and other queries </p>
	<p>Name:  {details.name}</p>
	<p>Phone:  {details.phone}</p>
	<p>OR</p>
	<p>Mail your problem</p>
	<p>Problem</p>
	<input className={styles.input} type="text" name="text" placeholder="Type the details By Focusing" autofocus></input>
	<button className={styles.button} onClick={() => submit()} >submit</button>
	
	
	</div>
	</div>	
  )
}

export async function getStaticProps(){
const details=Details()
return{
props:{details}}
}


function submit(){
	alert("we consider your problem")}


