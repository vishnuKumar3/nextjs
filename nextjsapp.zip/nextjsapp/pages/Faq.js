import styles from '../styles/Home.module.css'

export default function Faq() {
  return (
    <div className={styles.container}>
     <p className={styles.shrink}>This is Faq page</p>
    </div>
  )
}
