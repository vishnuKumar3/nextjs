import '../styles/globals.css'
import Head from 'next/head'
import styles from '../styles/Home.module.css'
import Link from "next/link"

function MyApp({ Component, pageProps }) {
  return(
	<div>
	<Head>
	<title>SS</title>
	<link rel="icon" href="image.jpg" href="/solution.svg"/>
	</Head>
	 

	<p className={styles.software}> SOFTWARE </p>
	<p className={styles.solutions}>SOLUTIONS </p>

	<ul className={styles.link1}>
	<Link href="/" ><p className={styles.innerlink1}>Home</p></Link>
	<Link href="/About" ><p className={styles.innerlink1}>About</p></Link>
	<Link href="/Career" ><p className={styles.innerlink1}>Career</p></Link>
	<Link href="/Faq" ><p className={styles.innerlink1}>Faq</p></Link>
	</ul>
	


	 <Component {...pageProps} />
	</div>)
}

export default MyApp
